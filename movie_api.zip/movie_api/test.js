console.log("HELLO Node!")
console.log('Goodbye.')